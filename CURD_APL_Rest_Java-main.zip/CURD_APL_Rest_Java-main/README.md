# CURD_APL_Rest_Java
Details of CURD API exercise- Expose REST API which perform the Select/GET call, Insert/POST call, Delete/DELETE call, Update/POST call. You can create a simple Students table in DB with 4..5 fields and perform these curd operations and expose it as REST API.
